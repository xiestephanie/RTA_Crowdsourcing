﻿
namespace MoonSharp.Interpreter.Interop.StandardDescriptors.HardwiredDescriptors
{
	public sealed class DefaultValue
	{
		public static readonly DefaultValue Instance = new DefaultValue();
	}
}
