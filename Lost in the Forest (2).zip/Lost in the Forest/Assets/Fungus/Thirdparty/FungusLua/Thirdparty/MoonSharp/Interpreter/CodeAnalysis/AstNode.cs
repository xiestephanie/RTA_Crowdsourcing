﻿
namespace MoonSharp.Interpreter.CodeAnalysis
{
	class AstNode
	{
	}
}
